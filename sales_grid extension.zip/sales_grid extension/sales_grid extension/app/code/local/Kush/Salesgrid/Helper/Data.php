<?php

class Kush_Salesgrid_Helper_Data extends Mage_Core_Helper_Abstract
{
   public function getCustomgridcolumns()
   {
     return  Mage::getStoreConfig("salesgrid/salescol/gridcolumns");
   }

}