<?php

$installer = $this;

$installer->startSetup();

$installer->run("ALTER TABLE `prdefinemessage` ADD `ordersorting` VARCHAR( 255 ) NOT NULL AFTER `title` ");

$installer->endSetup(); 