<?php
class Webpulsmobile_Prdefinemessage_Block_Adminhtml_Prdefinemessage extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_prdefinemessage';
    $this->_blockGroup = 'prdefinemessage';
    $this->_headerText = Mage::helper('prdefinemessage')->__('Item Manager');
    $this->_addButtonLabel = Mage::helper('prdefinemessage')->__('Add Item');
    parent::__construct();
  }
}