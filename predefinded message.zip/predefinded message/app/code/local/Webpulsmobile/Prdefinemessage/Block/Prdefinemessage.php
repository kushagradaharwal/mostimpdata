<?php
class Webpulsmobile_Prdefinemessage_Block_Prdefinemessage extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getPrdefinemessage()     
     { 
        if (!$this->hasData('prdefinemessage')) {
            $this->setData('prdefinemessage', Mage::registry('prdefinemessage'));
        }
        return $this->getData('prdefinemessage');
        
    }
}