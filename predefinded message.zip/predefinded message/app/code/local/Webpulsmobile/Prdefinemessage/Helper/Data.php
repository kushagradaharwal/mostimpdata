<?php

class Webpulsmobile_Prdefinemessage_Helper_Data extends Mage_Core_Helper_Abstract
{

function getEmailtemplate()
{
 return Mage::getStoreConfig("prdefinemessage/prdefinemessage/email_template");
} 

function getSuccessmessage()
{
 return Mage::getStoreConfig("prdefinemessage/prdefinemessage/success_mesasge");
} 

function getStorename()
{
 return Mage::getStoreConfig("general/store_information/name");
} 


}