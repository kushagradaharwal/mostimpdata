<?php

class BannerCustm_First_Model_Mysql4_First_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('first/first');
    }
}