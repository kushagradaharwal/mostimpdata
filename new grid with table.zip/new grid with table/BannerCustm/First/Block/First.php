<?php
class BannerCustm_First_Block_First extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getFirst()     
     { 
        if (!$this->hasData('first')) {
            $this->setData('first', Mage::registry('first'));
        }
        return $this->getData('first');
        
    }
	
//	public function getBanner()
//	{
//       $data = array();
//	   $model = Mage::getModel('first/first')->getCollection()
//			 ->setOrder('orderbybanner',"asc");
//		
//		$data = array();
//		foreach($model as $modeldata)
//		{
//		    
//				
//				$data[] = $modeldata;
//		}	
//	   return $data;
//	}
//	
}