<?php
class  BannerCustm_First_Block_Adminhtml_Firstsecond_Renderer_Image extends Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Abstract{
    public function render(Varien_Object $row)   {
        $html = '<img height="70" width="100" id="' . $this->getColumn()->getId() . '"
        src="'.Mage::getBaseUrl(Mage_Core_Model_Store::URL_TYPE_MEDIA).'firstbanner/resize/'.$row->getData($this->getColumn()->getIndex()) . '"';
        $html .= '/>';
		return $html;
    }
}
?>