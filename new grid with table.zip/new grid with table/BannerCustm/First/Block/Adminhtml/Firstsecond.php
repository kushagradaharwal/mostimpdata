<?php
class BannerCustm_First_Block_Adminhtml_Firstsecond extends Mage_Adminhtml_Block_Widget_Grid_Container
{
  public function __construct()
  {
    $this->_controller = 'adminhtml_firstsecond';
    $this->_blockGroup = 'first';
    $this->_headerText = Mage::helper('first')->__('Item Manager');
    $this->_addButtonLabel = Mage::helper('first')->__('Add Item');
    parent::__construct();
  }
}