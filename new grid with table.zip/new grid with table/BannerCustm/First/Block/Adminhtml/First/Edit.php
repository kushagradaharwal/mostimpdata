<?php

class BannerCustm_First_Block_Adminhtml_First_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
    public function __construct()
    {
        parent::__construct();
                 
        $this->_objectId = 'id';
        $this->_blockGroup = 'first';
        $this->_controller = 'adminhtml_first';
        
        $this->_updateButton('save', 'label', Mage::helper('first')->__('Save Item'));
        $this->_updateButton('delete', 'label', Mage::helper('first')->__('Delete Item'));
		
        $this->_addButton('saveandcontinue', array(
            'label'     => Mage::helper('adminhtml')->__('Save And Continue Edit'),
            'onclick'   => 'saveAndContinueEdit()',
            'class'     => 'save',
        ), -100);

        $this->_formScripts[] = "
            function toggleEditor() {
                if (tinyMCE.getInstanceById('first_content') == null) {
                    tinyMCE.execCommand('mceAddControl', false, 'first_content');
                } else {
                    tinyMCE.execCommand('mceRemoveControl', false, 'first_content');
                }
            }

            function saveAndContinueEdit(){
                editForm.submit($('edit_form').action+'back/edit/');
            }
        ";
    }

    public function getHeaderText()
    {
        if( Mage::registry('first_data') && Mage::registry('first_data')->getId() ) {
            return Mage::helper('first')->__("Edit Item '%s'", $this->htmlEscape(Mage::registry('first_data')->getTitle()));
        } else {
            return Mage::helper('first')->__('Add Item');
        }
    }
}